package com.example.ajaxkuayu;

/**
 * create by lishengbo on 2018-02-28 10:33
 */
public class UserBean {

    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
