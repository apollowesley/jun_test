package com.utility.log;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;

/**
 * 日志工具类
 * 
 * @author feng
 * @version 1.0
 * @since 2014/09/10
 */
public class LoggerUtil {
	private static LoggerUtil lu = null;
	private Logger logger = null;

	public LoggerUtil(Class<?> c) {
		this.logger = Logger.getLogger(c);

	}

	public static LoggerUtil getInstance(Class<?> c) {
		if (lu == null) {
			lu = new LoggerUtil(c);

		}
		return lu;
	}

	/**
	 * <b>得到日志对象</b>
	 * 
	 * @return Logger型
	 */
	public Logger getLogger() {
		return this.logger;
	}

	/**
	 * <b>输出info级别的日志</b><br>
	 * 用于输出一般的日志
	 * 
	 * @param o
	 *            日志信息
	 */
	public void info(Object o) {
		// Logger logger=getLogger();
		logger.info(o);

	}

	/**
	 * <b>输出error级别的日志</b><br>
	 * 用于输出错误性质的日志。如果是要输出异常（Exception）类的日志，直接传入Exception对象即可
	 * 
	 * @param o
	 */
	public void error(Object o) {
		if (o instanceof Exception) {
			logger.error(getTrace((Exception) o));
		} else {
			logger.error(o);
		}
	}

	/**
	 * 
	 * @param t
	 * @return 字符串
	 */
	private String getTrace(Throwable t) {
		StringWriter stringWriter = new StringWriter();
		PrintWriter writer = new PrintWriter(stringWriter);
		t.printStackTrace(writer);
		StringBuffer buffer = stringWriter.getBuffer();
		return buffer.toString();
	}
}
