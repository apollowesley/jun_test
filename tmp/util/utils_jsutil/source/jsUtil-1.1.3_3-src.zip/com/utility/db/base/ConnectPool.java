package com.utility.db.base;

import java.sql.Connection;

import com.utility.db.DBUtil.DATABASETYPE;

public interface ConnectPool {
	public Connection getConnection(DATABASETYPE TYPE);
	public Connection getConnection();
}
