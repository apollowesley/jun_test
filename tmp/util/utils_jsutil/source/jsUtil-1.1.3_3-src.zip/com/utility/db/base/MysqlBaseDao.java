package com.utility.db.base;

import com.utility.db.DBUtil;
import com.utility.db.DBUtil.DATABASETYPE;
import com.utility.init.WebInitUtil;

public class MysqlBaseDao implements DaoInterface {
	protected DBUtil dbu = null;
	public WebInitUtil initUtil = WebInitUtil.INST;
	//public static final Constant c=Constant.getInstance();
	public MysqlBaseDao(){		
		this.connection();
	}
	@Override
	public boolean connection() {
		// TODO Auto-generated method stub	
		boolean isPool=Boolean.valueOf(initUtil.getText("MYSQL_CONNECT_POOL"));
		
		boolean r =false;
		if(!isPool){
			this.dbu = new DBUtil(initUtil.getText("MYSQL_DB_USER"), initUtil.getText("MYSQL_DB_PASSWORD"),
					initUtil.getText("MYSQL_DB_IP"), initUtil.getText("MYSQL_DB_NAME"),initUtil.getText("MYSQL_DB_PORT"));
			
		}
		else{
			this.dbu = new DBUtil();
			this.dbu.setPool(true);
		}
		boolean isPrintSQL=Boolean.valueOf(initUtil.getText("PRINT_SQL_ENABLE"));
		this.dbu.setPrintSQL(isPrintSQL); 
		 r = this.dbu.connection(DATABASETYPE.MYSQL);
		return r;
		
	}

	@Override
	public void closeDB() {
		// TODO Auto-generated method stub
		this.dbu.releaseConn();
	}

}
