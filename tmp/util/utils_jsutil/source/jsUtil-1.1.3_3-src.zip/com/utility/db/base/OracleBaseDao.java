package com.utility.db.base;

import com.utility.db.DBUtil;
import com.utility.db.DBUtil.DATABASETYPE;
import com.utility.init.WebInitUtil;

public class OracleBaseDao implements DaoInterface {
	protected DBUtil dbu = null;
	public WebInitUtil initUtil = WebInitUtil.INST;
	//public static final Constant c=Constant.getInstance();
	public OracleBaseDao(){		
		this.connection();
	}
	@Override
	public boolean connection() {
		// TODO Auto-generated method stub
		boolean isPool=Boolean.valueOf(initUtil.getText("ORACLE_CONNECT_POOL"));
		boolean r =false;
		if(!isPool){
			this.dbu = new DBUtil(initUtil.getText("ORACLE_DB_USER"), initUtil.getText("ORACLE_DB_PASSWORD"),
					initUtil.getText("ORACLE_DB_IP"), initUtil.getText("ORACLE_DB_NAME"),initUtil.getText("ORACLE_DB_PORT"));
			
		}
		else{
			this.dbu = new DBUtil();
			this.dbu.setPool(true);
		}
		boolean isPrintSQL=Boolean.valueOf(initUtil.getText("PRINT_SQL_ENABLE"));
		this.dbu.setPrintSQL(isPrintSQL); 
		 r = this.dbu.connection(DATABASETYPE.ORACLE);
		return r;
	}

	@Override
	public void closeDB() {
		// TODO Auto-generated method stub
		this.dbu.releaseConn();
	}

}
