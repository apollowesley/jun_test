package com.utility.db;

import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


import com.utility.date.DateUtil;
import com.utility.db.annotation.BeanAnnotation;
import com.utility.db.annotation.TableAnnotation;
import com.utility.db.annotation.FieldAnnotation;
import com.utility.exception.SystemException;
import com.utility.init.WebInitUtil;
import com.utility.log.LoggerUtil;

/**
 * <b>数据库连接类</b><br>
 * <br>
 * 
 * <pre>
 * 在不启用tomcat等服务器的情况下，可通过以下方式测试使用。<br>
 * DBUtil dbu = new DBUtil("sa", "sa123", "192.168.1.246", "emcpSite001","1433");
 * if (dbu.connection(DATABASETYPE.SQLSERVER)) {
 * 		dbu.prepareSQL("select * from dbo.T_ViewPointHistory_000_0100 where  BuildCode=?"); 
 * 		dbu.setParameter(1, "B01");
 * 		List<Map<Object, Object>> rs = dbu.execQuery();
 * 		for (Map<Object, Object> result : rs) {
 * 			System.out.print(result.get("EnergyKindCode") + " ");
 * 			System.out.print(result.get("EnergyItemCode") + " ");
 * 			System.out.print(result.get("CurrentTime") + " ");
 * 			System.out.print(result.get("CurrentValue") + " ");
 * 			System.out.println(result.get("Flag") + " ");
 * 
 * 		}
 * 		dbu.releaseConn();
 * }
 * </pre>
 * 
 * @author feng
 * @version 1.1.0
 * @since 2015/1/10
 */
public class DBUtil {
	private static LoggerUtil log = new LoggerUtil(DBUtil.class);
	private boolean isConfig = false;
	private boolean isPool = false;
	private boolean isPrintSQL = true;
	private Connection con = null;
	private PreparedStatement pstmt = null;
	private Statement stmt = null;
	private CallableStatement cstmt = null;

	private ResultSet rs = null;
	private String DBUser;
	private String DBPassword;
	private String DBServer;
	private String DBNAME;
	private String Port;
	private String driver = null;
	private String url = null;
	private static final String MYSQL_DRIVER = "org.gjt.mm.mysql.Driver";
	private static final String SQLSERVER_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private int pageNumber = 0;
	private int pageSize = 0;
	private DATABASETYPE currentDBType = null;

	public DBUtil() {

	}

	/**
	 * 数据库类型
	 * 
	 * @author feng
	 * 
	 */
	public enum DATABASETYPE {
		MYSQL, SQLSERVER, ORACLE
	}

	/**
	 * 通过数据库参数构建DBUtil对象
	 * 
	 * @param DBUser
	 *            用户名
	 * @param DBPassword
	 *            密码
	 * @param DBServer
	 *            数据库服务器IP
	 * @param DBNAME
	 *            数据库名称
	 */
	public DBUtil(String DBUser, String DBPassword, String DBServer,
			String DBNAME, String Port) {
		this.DBUser = DBUser;
		this.DBPassword = DBPassword;
		this.DBServer = DBServer;
		this.DBNAME = DBNAME;
		this.Port = Port;
	}

	/**
	 * 通过数据库参数配置文件构建DBUtil对象
	 * 
	 * @param configFile
	 */
	public DBUtil(String configFile) {
		isConfig = true;
		DocumentBuilderFactory dbf = null;
		DocumentBuilder db = null;
		Document doc = null;
		InputStream in = null;
		NodeList nl = null;
		Element elt = null;
		try {
			dbf = DocumentBuilderFactory.newInstance();
			db = dbf.newDocumentBuilder();
			in = new FileInputStream(this.getClass().getResource("/").getPath()
					+ configFile);
			doc = db.parse(in);

			nl = doc.getElementsByTagName("driver");
			elt = (Element) nl.item(0);
			this.driver = elt.getAttribute("class");

			nl = doc.getElementsByTagName("url");
			elt = (Element) nl.item(0);
			this.url = elt.getAttribute("value");

			nl = doc.getElementsByTagName("login");
			elt = (Element) nl.item(0);
			this.DBUser = elt.getAttribute("userName");
			this.DBPassword = elt.getAttribute("password");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
		}
	}

	/**
	 * 获得Connection对象
	 * 
	 * @return Connection型
	 */
	public Connection getConn() {
		return this.con;
	}

	/**
	 * 连接数据库
	 * 
	 * @param TYPE
	 *            数据库类型
	 * @return true：连接成功；false：连接失败
	 */
	public boolean connection(DATABASETYPE TYPE) {
		this.currentDBType = TYPE;
		try {
			if (this.isPool) {

				switch (TYPE) {
				case MYSQL:
					this.con = WebInitUtil.INST.getCpdsMysql().getConnection();
					break;
				case SQLSERVER:
					this.con = WebInitUtil.INST.getCpdsMssql().getConnection();
					break;
				case ORACLE:
					this.con = WebInitUtil.INST.getCpdsOracle().getConnection();
					break;
				}
			} else {
				if (!isConfig) {
					switch (TYPE) {
					case MYSQL:
						Class.forName(DBUtil.MYSQL_DRIVER).newInstance();
						url = "jdbc:mysql://" + this.DBServer + ":" + this.Port
								+ "/" + this.DBNAME
								+ "?useUnicode=true&characterEncoding=utf-8";						
						break;
					case SQLSERVER:
						Class.forName(DBUtil.SQLSERVER_DRIVER).newInstance();
						url = "jdbc:sqlserver://" + this.DBServer + ":"
								+ this.Port + ";databasename=" + this.DBNAME;
						break;
					case ORACLE:
						Class.forName(DBUtil.ORACLE_DRIVER).newInstance();
						url = "jdbc:oracle:thin:@" + this.DBServer + ":"
								+ this.Port + ":" + this.DBNAME;
						break;
					}
				} else {
					Class.forName(this.driver).newInstance();
				}
				if (this.con == null)
					this.con = DriverManager.getConnection(url, this.DBUser,
							this.DBPassword);
			}
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
			// return false;
		}

	}

	/**
	 * <b>开启事物</b><br>
	 * 如果需要使用事物时，先调用此方法。
	 * 
	 * @throws SQLException
	 */
	public void beginTransaction() {
		try {
			this.con.setAutoCommit(false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
		}
	}

	/**
	 * <b>数据回滚</b><br>
	 * 在数据库操作发生异常时，捕获异常并调用此方法。
	 */
	public void rollback() {
		try {
			this.con.rollback();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
		}
	}

	/**
	 * <b>提交事物</b><br>
	 * 如果调用了beginTransaction()方法，需要在最后调用此方法进行提交并反映到数据库。
	 * 
	 * @throws SQLException
	 */
	public void commit() {
		try {
			this.con.commit();
			this.con.setAutoCommit(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}

	private boolean isStartBatch = false;

	/**
	 * <b>使用批处理</b><br>
	 * 如果需要一次性执行多条sql文，则需要先调用此方法。配合addBatch()使用
	 * 
	 * @throws SQLException
	 */
	public void startBatch() {
		isStartBatch = true;
		try {
			this.stmt = this.con.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * <b>添加批处理</b><br>
	 * 配合startBatch()使用
	 * 
	 * @throws SQLException
	 */
	public void addBatch() {
		try {
			this.pstmt.addBatch();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}

	private void setInitAutoCommit() {
		try {
			if (this.con.getAutoCommit()) {
				this.con.setAutoCommit(false);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	/**
	 * <b>添加批处理</b><br>
	 * 配合startBatch()使用
	 * 
	 * @param sql
	 *            要执行sql语句
	 * @throws SQLException
	 */
	public void addBatch(String sql) {
		try {
			if (this.isPrintSQL) {
				log.info("SQL:" + sql);
			}
			this.stmt.addBatch(sql);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}

	/**
	 * <b>载入sql文</b><br>
	 * 
	 * @param strSQL
	 *            要执行sql语句
	 * @throws SQLException
	 */
	public void prepareSQL(String strSQL) {
		try {
			if (this.pageNumber > 0 && this.pageSize > 0) {
				if (this.currentDBType == DATABASETYPE.MYSQL) {
					strSQL = strSQL + " limit "
							+ (this.pageNumber * this.pageSize - this.pageSize)
							+ "," + this.pageSize;
				} else if (this.currentDBType == DATABASETYPE.ORACLE) {
					strSQL = "SELECT * FROM ( SELECT A.*, ROWNUM RN FROM ("
							+ strSQL
							+ ") A WHERE ROWNUM <= "
							+ (this.pageNumber * this.pageSize)
							+ " ) WHERE RN >= "
							+ (this.pageNumber * this.pageSize - this.pageSize + 1);

				} else if (this.currentDBType == DATABASETYPE.SQLSERVER) {
					strSQL = "select * from(select  * ,row_number() OVER (order BY CONVERT(varchar(100), GETDATE(), 23)) as RN from ("
							+ strSQL
							+ ") pageA ) pageB where RN<="
							+ (this.pageNumber * this.pageSize)
							+ " and RN>="
							+ (this.pageNumber * this.pageSize - this.pageSize + 1);

				}
				this.setPageNumber(0);
				this.setPageSize(0);
			}
			if (this.isPrintSQL) {
				log.info("SQL:" + strSQL);
			}

			this.pstmt = this.con.prepareStatement(strSQL);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}

	/**
	 * <b>设置参数</b><br>
	 * 设置prepareSQL(String strSQL)中的sql参数值
	 * 
	 * @param parameterIndex
	 *            参数序号
	 * @param objectValue
	 *            对应参数值
	 * @throws SQLException
	 */
	public void setParameter(int parameterIndex, Object objectValue) {
		try {
			this.pstmt.setObject(parameterIndex, objectValue);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}

	/**
	 * <b>取得结果集</b><br>
	 * 执行查询并返回数据集
	 * 
	 * @return List型
	 */
	public List<Map<Object, Object>> execQuery() {
		Map<Object, Object> resultsMap = null;
		List<Map<Object, Object>> resultList = new ArrayList<Map<Object, Object>>();
		try {
			ResultSetMetaData titleName = null;
			if (!isProcedure) {
				this.rs = this.pstmt.executeQuery();
				titleName = this.pstmt.getMetaData();
			} else {
				this.rs = this.cstmt.executeQuery();
				titleName = this.cstmt.getMetaData();
			}

			int totalColumn = titleName.getColumnCount();
			while (this.rs.next()) {
				resultsMap = new HashMap<Object, Object>();
				for (int i = 1; i <= totalColumn; i++) {
					resultsMap.put(titleName.getColumnName(i),
							this.rs.getObject(i));
				}
				resultList.add(resultsMap);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
		return resultList;
	}

	/**
	 * <b>取得结果集</b><br>
	 * 执行查询并返回数据集
	 * 
	 * @return 对象List
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List execQuery(Class<?> cls) {
		List objs = new ArrayList();
		try {
			ResultSetMetaData titleName = null;
			if (!isProcedure) {
				this.rs = this.pstmt.executeQuery();
				titleName = this.pstmt.getMetaData();
			} else {
				this.rs = this.cstmt.executeQuery();
				titleName = this.cstmt.getMetaData();
			}

			int totalColumn = titleName.getColumnCount();
			Method[] methods = cls.getDeclaredMethods();
			boolean flag = false;

			while (this.rs.next()) {
				Object o = cls.newInstance();
				for (int i = 1; i <= totalColumn; i++) {
					for (Method method : methods) {
						flag = method.isAnnotationPresent(BeanAnnotation.class);
						// System.out.println(method.isVarArgs());
						if (!flag || method.getParameterTypes().length == 0) {

							continue;
						}
						BeanAnnotation annotation = method
								.getAnnotation(BeanAnnotation.class);
						String fieldName = annotation.targetField();

						if (titleName.getColumnName(i).equals(fieldName)) {
							Method m = cls.getDeclaredMethod(method.getName(),
									method.getParameterTypes());
							m.invoke(o, this.rs.getObject(i));
							break;
						}
					}
				}
				objs.add(o);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
		return objs;
	}
	/**
	 * <b>添加数据</b><br> 
	 * 
	 * @param cls
	 * @param o
	 * @return
	 */
	public int[] registNewObject(Class<?> cls, Object o)  {
		try {
		boolean flag = false;
		flag = cls.isAnnotationPresent(TableAnnotation.class);
		if (!flag) {
			return null;
		}
		TableAnnotation ta = cls.getAnnotation(TableAnnotation.class);
		String tableName = ta.targetTable();
		String sql = "insert into " + tableName + " (";
		String options = "";
		String values = "";
	
		flag = false;
		Method[] methods = cls.getDeclaredMethods();
		
		for (Method method : methods) {
			flag = method.isAnnotationPresent(BeanAnnotation.class);			
			if (!flag || method.getParameterTypes().length == 0) {
				continue;
			}
			BeanAnnotation annotation = method
					.getAnnotation(BeanAnnotation.class);
			String fieldName = annotation.targetField();
			String setMethodName = method.getName();
			String getMethodName = "get"
					+ setMethodName.substring(3);

			Method m = cls.getDeclaredMethod(getMethodName);
			Object value = m.invoke(o);
			// record.put(fieldName, value);
			if(value!=null){
				//options += fieldName + ",";
				//values +=  "'" + value + "',";
				
				flag = method.isAnnotationPresent(FieldAnnotation.class);
				if (flag) {
					FieldAnnotation fannotation = method
							.getAnnotation(FieldAnnotation.class);
					boolean isPrimaryKey = fannotation.isPrimaryKey();
					boolean isIncrement = fannotation.isIncrement();
					if (!isPrimaryKey||(isPrimaryKey&&!isIncrement)) {
						options += fieldName + ",";
						 if((value instanceof Double)||(value instanceof Integer)||(value instanceof Float)||(value instanceof BigDecimal)){
							 values +=  "" + value + ",";
						 }
						 else{
							 if(value instanceof Date){
								 values +=  "'" + DateUtil.getDateForPara((Date)value, DateUtil.DEFAULT_DATETIME_FORMAT) + "',";
							 }
							 else  if(((String)value).toLowerCase().indexOf("md5(")>-1){
								 values +=  "" + value + ",";
							 }
							 else{
								 values +=  "'" + value + "',";
							 }
							
						 }
					}
				}
				else{
					options += fieldName + ",";
				//	values +=  "'" + value + "',";
					 if((value instanceof Double)||(value instanceof Integer)||(value instanceof Float)||(value instanceof BigDecimal)){
						 values +=  "" + value + ",";
					 }
					 else{
						 if(value instanceof Date){
							 values +=  "'" + DateUtil.getDateForPara((Date)value, DateUtil.DEFAULT_DATETIME_FORMAT) + "',";
						 }
						 else  if(((String)value).toLowerCase().indexOf("md5(")>-1){
							 values +=  "" + value + ",";
						 }
						 else{
							 values +=  "'" + value + "',";
						 }
					 }

						 
				}
			}
			

			

		}
		if (values.length() > 0 ) {
			values = values.substring(0, values.length() - 1);
		}
		if (options.length() > 0 ) {
			options = options.substring(0, options.length() - 1);
			
		}
		
		if (values.length() > 0 &&options.length() > 0) {
			sql = sql + options +") values("+ values+")";
		}
		else{
			sql = "";
		}
		if(sql.length()>0){			
			this.prepareSQL(sql);
			int[] r = this.execSQL();
			return r;
		}
		
		return null;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}
	
/** 
 * <b>修改数据</b><br> * 
 * 
 * @param cls
 * @param o
 * @return
 */
	public int[] execUpdate(Class<?> cls, Object o)  {
		try {
		boolean flag = false;
		flag = cls.isAnnotationPresent(TableAnnotation.class);
		if (!flag) {
			return null;
		}
		TableAnnotation ta = cls.getAnnotation(TableAnnotation.class);
		String tableName = ta.targetTable();
		String sql = "update " + tableName + " set ";
		String options = "";
		String where = "";
		flag = false;
		Method[] methods = cls.getDeclaredMethods();
		// Map<String,Object> record=new HashMap<String,Object>();

		for (Method method : methods) {
			flag = method.isAnnotationPresent(BeanAnnotation.class);
			// System.out.println(method.isVarArgs());
			if (!flag || method.getParameterTypes().length == 0) {

				continue;
			}
			BeanAnnotation annotation = method
					.getAnnotation(BeanAnnotation.class);
			String fieldName = annotation.targetField();
			String setMethodName = method.getName();
			String getMethodName = "get"
					+ setMethodName.substring(3);

			Method m = cls.getDeclaredMethod(getMethodName);
			Object value = m.invoke(o);
			// record.put(fieldName, value);
			if(value!=null){
				
				if((value instanceof Double)||(value instanceof Integer)||(value instanceof Float)||(value instanceof BigDecimal)){
					options += fieldName + "=" + value + ",";
				 }
				 else{
					 
					 if(value instanceof Date){						
						 options += fieldName + "='" + DateUtil.getDateForPara((Date)value, DateUtil.DEFAULT_DATETIME_FORMAT) + "',";
					 }
					 else  if(((String)value).toLowerCase().equals("null")){
						 options += fieldName + "=null,";
					 }
					 else  if(((String)value).toLowerCase().indexOf("md5(")>-1){
						 options += fieldName + "=" + value + ",";
					 }
					 else{
						 options += fieldName + "='" + value + "',";
					 }
				 }
			}
			

			flag = method.isAnnotationPresent(FieldAnnotation.class);
			if (flag) {
				FieldAnnotation fannotation = method
						.getAnnotation(FieldAnnotation.class);
				boolean isPrimaryKey = fannotation.isPrimaryKey();
				if (isPrimaryKey) {
					where = " where " + fieldName + "='" + value + "'";
				}
			}

		}
		if (options.length() > 0 && where.length() > 0) {
			options = options.substring(0, options.length() - 1);
			sql = sql + options + where;
		} else {
			sql = "";
		}
		if(sql.length()>0){
			this.prepareSQL(sql);
			int[] r = this.execSQL();
			return r;
		}
		
		return null;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}
	
	/**
	 * <b>删除数据</b><br> 
	 * 
	 * @param cls
	 * @param os
	 */
	public void deleteObjects(Class<?> cls, List<?> os)  {
		try{
		for(Object o:os ){
			this.deleteObject(cls, o);
		}
		} catch (Exception e) {			
			this.setInitAutoCommit();
			throw new SystemException(e);
		}
	}
	/** 
	 * <b>删除数据</b><br> 
	 * 
	 * @param cls
	 * @param o
	 * @return
	 */
		public int[] deleteObject(Class<?> cls, Object o)  {
			try {
			boolean flag = false;
			flag = cls.isAnnotationPresent(TableAnnotation.class);
			if (!flag) {
				return null;
			}
			TableAnnotation ta = cls.getAnnotation(TableAnnotation.class);
			String tableName = ta.targetTable();
			String sql = "delete from " + tableName;			
			String where = "";
			flag = false;
			Method[] methods = cls.getDeclaredMethods();
			// Map<String,Object> record=new HashMap<String,Object>();

			for (Method method : methods) {
				flag = method.isAnnotationPresent(BeanAnnotation.class);
				// System.out.println(method.isVarArgs());
				if (!flag || method.getParameterTypes().length == 0) {

					continue;
				}
				BeanAnnotation annotation = method
						.getAnnotation(BeanAnnotation.class);
				String fieldName = annotation.targetField();
				String setMethodName = method.getName();
				String getMethodName = "get"
						+ setMethodName.substring(3);

				Method m = cls.getDeclaredMethod(getMethodName);
				Object value = m.invoke(o);
				// record.put(fieldName, value);
				if(value!=null){
					flag = method.isAnnotationPresent(FieldAnnotation.class);
					if (flag) {
						FieldAnnotation fannotation = method
								.getAnnotation(FieldAnnotation.class);
						boolean isPrimaryKey = fannotation.isPrimaryKey();
						if (isPrimaryKey) {
							where = " where " + fieldName + "='" + value + "'";
						}
					}
				}
				

		

			}
			if (where.length() > 0) {			
				sql = sql + where;
			} else {
				sql = "";
			}
			if(sql.length()>0){
				this.prepareSQL(sql);
				int[] r = this.execSQL();
				return r;
			}
			
			return null;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.error(e);// 打印日志
				this.setInitAutoCommit();
				throw new SystemException(e);
			}
		}
	/**
	 * <b>执行sql</b><br>
	 * 
	 * @return int[]型
	 */
	public int[] execSQL() {
		int[] r = new int[1];
		try {
			if (isStartBatch) {
				r = this.stmt.executeBatch();
				isStartBatch = false;
			} else {
				r[0] = this.pstmt.executeUpdate();
			}
			return r;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			this.setInitAutoCommit();
			throw new SystemException(e);
			// return 0;
		}

	}

	private boolean isProcedure = false;

	/**
	 * <b>执行sql</b><br>
	 * 
	 * @param functionName
	 *            存储过程名称
	 * @param input
	 *            输入参数
	 * @return 查询结果(Map List)
	 */
	public List<Map<Object, Object>> prepareCall(String functionName,
			Map<String, Object> input) {
		try {
			isProcedure = true;
			String callString = this.getFunctionName(functionName, input, null,
					null);
			// 创建存储过程的对象
			this.cstmt = this.con.prepareCall(callString);
			// 给存储过程参数设置值

			if (input != null) {
				for (String key : input.keySet()) {
					this.cstmt.setObject(key, input.get(key));
				}
			}

			return this.execQuery();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
			// return 0;
		} finally {
			isProcedure = false;
		}
	}

	/**
	 * <b>执行sql</b><br>
	 * 
	 * @param cls
	 *            实体类
	 * @param functionName
	 *            存储过程名称
	 * @param input
	 *            输入参数
	 * @return 查询结果(实体List)
	 */
	@SuppressWarnings("rawtypes")
	public List prepareCall(Class<?> cls, String functionName,
			Map<String, Object> input) {
		try {
			isProcedure = true;
			String callString = this.getFunctionName(functionName, input, null,
					null);
			// 创建存储过程的对象
			this.cstmt = this.con.prepareCall(callString);
			// 给存储过程参数设置值

			if (input != null) {
				for (String key : input.keySet()) {
					this.cstmt.setObject(key, input.get(key));
				}
			}

			return this.execQuery(cls);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
			// return 0;
		} finally {
			isProcedure = false;
		}
	}

	/**
	 * <b>存储过程调用</b><br>
	 * 
	 * @param functionName
	 *            存储过程名称
	 * @param input
	 *            输入参数
	 * @param output
	 *            输出参数
	 * @param outinput
	 *            输入输出参数
	 * @param types
	 *            输出参数类型
	 * @return Map<String,Object>型 输出参数结果
	 */
	public Map<String, Object> prepareCall(String functionName,
			Map<String, Object> input, Map<String, Object> output,
			Map<String, Object> outinput, Map<String, Integer> types) {
		try {
			Map<String, Object> returnValue = new HashMap<String, Object>();
			String callString = this.getFunctionName(functionName, input,
					output, outinput);

			// 创建存储过程的对象
			this.cstmt = this.con.prepareCall(callString);

			// 给存储过程参数设置值
			if (input != null && outinput != null) {
				input.putAll(outinput);
			}
			if (input == null && outinput != null) {
				input = outinput;
			}
			if (input != null) {
				for (String key : input.keySet()) {
					this.cstmt.setObject(key, input.get(key));
				}
			}

			// 注册存储过程的输出参数
			if (output != null && outinput != null) {
				output.putAll(outinput);
			}
			if (output == null && outinput != null) {
				output = outinput;
			}
			if (output != null) {
				for (String key : output.keySet()) {
					// c.setObject(key, output.get(key));
					this.cstmt.registerOutParameter(key, types.get(key));
				}
			}

			// 执行存储过程
			this.cstmt.execute();
			if (output != null) {
				// 得到存储过程的输出参数值
				for (String key : output.keySet()) {
					returnValue.put(key, this.cstmt.getObject(key));
				}
			}

			// System.out.println (c.getInt(2));
			return returnValue;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
			// return 0;
		}
	}

	/**
	 * <b>构建存储过程名称</b><br>
	 * 
	 * @param functionName
	 *            存储过程名称
	 * @param input
	 *            输入参数
	 * @param output
	 *            输出参数
	 * @param outinput
	 *            输入输出参数
	 * @return 返回构建好的名称字串
	 */
	private String getFunctionName(String functionName,
			Map<String, Object> input, Map<String, Object> output,
			Map<String, Object> outinput) {
		String callString = "";
		String callStringL = "{call ";
		String callStringML = functionName + "(";
		String callStringMM = "";
		String callStringMR = ")";
		String callStringR = "}";
		int parameterCount = (input != null ? input.size() : 0)
				+ (output != null ? output.size() : 0)
				+ (outinput != null ? outinput.size() : 0);
		for (int i = 0; i < parameterCount; i++) {

			if (i == parameterCount - 1) {
				callStringMM += "?";
			} else {
				callStringMM += "?,";
			}

		}
		if (callStringMM.length() == 0) {
			callString = callStringL + functionName + callStringR;
		} else {
			callString = callStringL + callStringML + callStringMM
					+ callStringMR + callStringR;
		}
		log.info("[调用存储过程]：" + callString);
		return callString;
	}

	/**
	 * <b>启用连接池</b><br>
	 * 如果需要启用连接池功能，调用此方法启用。
	 * 
	 * @param isPool
	 *            true的时候启用，false不启用。默认false
	 */
	public void setPool(boolean isPool) {
		this.isPool = isPool;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	/**
	 * <b>启用SQL日志打印</b><br>
	 * 
	 * @param isPrintSQL
	 *            true输出SQL日志，true不输出SQL日志。默认true
	 */
	public void setPrintSQL(boolean isPrintSQL) {
		this.isPrintSQL = isPrintSQL;
	}

	/**
	 * <b>分页显示页码</b><br>
	 * 当前第几页
	 * 
	 * @param pageNumber
	 *            页码（整数型）
	 */
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getPageSize() {
		return pageSize;
	}

	/**
	 * <b>分页大小</b><br>
	 * 每页显示记录数
	 * 
	 * @param pageSize
	 *            记录数（整数型）
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * <b>唯一结果查询</b><br>
	 * 
	 * @param tableClass
	 *            实体类
	 * @param keyValue
	 *            主键信息（Key:主键字段名称；value:对应字段值）
	 * @return 以bean的形式返回唯一结果
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Object getDataByPrimaryKey(Class<?> tableClass,
			Map<String, Object> keyValue) throws SystemException {
		boolean flag = tableClass.isAnnotationPresent(TableAnnotation.class);
		if (!flag) {
			log.error(new SystemException("请给[" + tableClass.getName()
					+ "]类加DB关联“批注”!"));
			return null;
		} else {
			TableAnnotation ta = tableClass
					.getAnnotation(TableAnnotation.class);
			String tableName = ta.targetTable();
			this.prepareSQL(this.makeWhere(tableName, keyValue));
			List<Object> rs = this.execQuery(tableClass);
			if (rs.isEmpty()) {
				return null;
			}
			return rs.get(0);
		}

	}

	private String makeWhere(String tableName, Map<String, Object> keyValue) {
		String sql = "select * from " + tableName;
		String where = " ";
		int i = 0;
		if (keyValue.size() > 0) {
			where = " where ";
		}
		for (String key : keyValue.keySet()) {
			if (i == (keyValue.size() - 1)) {
				where += key + "='" + keyValue.get(key) + "' ";
			} else {
				where += key + "='" + keyValue.get(key) + "' and ";
			}
			i++;
		}
		/**
		 * if (this.isPrintSQL) { log.info("SQL:" + sql + where);
		 * 
		 * }
		 */
		return sql + where;
	}

	/**
	 * <b>唯一结果查询</b><br>
	 * 
	 * @param tableName
	 *            表名称、查询名称
	 * @param keyValue
	 *            主键信息（Key:主键字段名称；value:对应字段值）
	 * @return 唯一结果
	 * @throws Exception
	 */
	public Map<Object, Object> getDataByPrimaryKey(String tableName,
			Map<String, Object> keyValue) throws SystemException {
		this.prepareSQL(this.makeWhere(tableName, keyValue));
		List<Map<Object, Object>> rs = this.execQuery();
		if (rs.isEmpty()) {
			return null;
		}
		return rs.get(0);
	}

	/**
	 * <b>释放连接</b><br>
	 * 你的DAO每次用完后，记得调用此方法以释放数据库连接。
	 */
	public void releaseConn() {
		try {
			if (this.rs != null) {
				this.rs.close();
			}
			if (this.pstmt != null) {
				this.pstmt.close();
			}
			if (this.stmt != null) {
				this.stmt.close();
			}
			if (this.cstmt != null) {
				this.cstmt.close();
			}
			if (this.con != null) {
				this.con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
