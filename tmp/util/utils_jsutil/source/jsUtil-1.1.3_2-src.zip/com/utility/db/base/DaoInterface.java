package com.utility.db.base;

public interface DaoInterface {
public boolean connection();
public void closeDB();
}
