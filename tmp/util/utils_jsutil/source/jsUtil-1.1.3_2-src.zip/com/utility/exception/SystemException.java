package com.utility.exception;
/**
 * 异常处理类
 * @author 冯
 *
 */
public class SystemException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	
	public SystemException(Throwable throwable) {

		super(throwable);

	}
	public SystemException(String frdMessage) {

	       super(createFriendlyErrMsg(frdMessage));

	    }

	public static String createFriendlyErrMsg(String msgBody) {

		String prefixStr = "抱歉。";

		String suffixStr = "程序异常！";

		StringBuffer friendlyErrMsg = new StringBuffer();

		friendlyErrMsg.append(prefixStr);

		friendlyErrMsg.append(msgBody);

		friendlyErrMsg.append(suffixStr);

		return friendlyErrMsg.toString();

	}

}
