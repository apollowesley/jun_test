package com.utility.init;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.PropertyConfigurator;

import com.utility.db.DBUtil.DATABASETYPE;
import com.utility.db.base.ConnectPool;
import com.utility.log.LoggerUtil;

/**
 * <b>JSUtil插件启动类</b> <br>
 * 在使用JSUtil之前需要在web.xml中配置（具体参看readme.pdf）
 * 
 * @author feng
 * @version 1.0
 * @since 2014/11/10
 */
public class WebInitUtil extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static String BASE_PATH = null;
	private static LoggerUtil log = new LoggerUtil(WebInitUtil.class);
	/**
	 * log4j配置文件路径
	 */
	private static final String LOGPATH = File.separator + "WEB-INF"
			+ File.separator + "log4j.properties";
	 
	/**
	 * 系统配置文件路径
	 */
	private static final String CONSTANT_PATH = File.separator + "WEB-INF"
			+ File.separator + "SysSetings.properties";
	private Properties P = null;
	/**
	 * WebInitUtil静态对象
	 */
	public static WebInitUtil INST = null;
	
	/**
	 * Mysql连接池对象
	 */
	private ConnectPool cpdsMysql = null;
	 
	/**
	 * Oracle连接池对象
	 */
	private ConnectPool cpdsOracle = null;
	
	/**
	 * Sql server连接池对象
	 */
	private ConnectPool cpdsMssql = null;

	/**
	 * <b>构造函数</b> <br>
	 */
	public WebInitUtil() {
		super();
		INST = this;
	}

	/**
	 * * <b>销毁 servlet</b> <br>
	 */
	public void destroy() {
		super.destroy();

	}

	/**
	 * <b>初始化调用数</b> <br>
	 */
	public void init() throws ServletException {

		String logDirectory = null;
		BASE_PATH = new File(new File(WebInitUtil.class.getResource("/")
				.getPath()).getParent()).getParent();
		logDirectory = BASE_PATH + File.separator + "logs" + File.separator;

		if (!new File(logDirectory).exists()) {
			new File(logDirectory).mkdirs();
		}

		// 初始化log4j
		String logFile = BASE_PATH + LOGPATH;
		log4jInit(logFile, logDirectory);

		// 装载配置文件SysSetings.properties
		initConfig(BASE_PATH + CONSTANT_PATH);

		// 初始化链接池
		boolean isPoolM = Boolean
				.valueOf((INST.getText("MYSQL_CONNECT_POOL") == null || INST
						.getText("MYSQL_CONNECT_POOL").length() == 0) ? "false"
						: INST.getText("MYSQL_CONNECT_POOL"));
		boolean isPoolO = Boolean
				.valueOf((INST.getText("ORACLE_CONNECT_POOL") == null || INST
						.getText("ORACLE_CONNECT_POOL").length() == 0) ? "false"
						: INST.getText("ORACLE_CONNECT_POOL"));
		boolean isPoolS = Boolean
				.valueOf((INST.getText("MSSQL_CONNECT_POOL") == null || INST
						.getText("MSSQL_CONNECT_POOL").length() == 0) ? "false"
						: INST.getText("MSSQL_CONNECT_POOL"));
		if (isPoolM || isPoolO || isPoolS) {
			initConnectPool(isPoolM, isPoolO, isPoolS);
		}

	}


	/**
	 * <b>初始化链接池</b> <br>
	 * 
	 * @param isPoolM Mysql数据库连接池开启Flag
	 * @param isPoolO  Oracle数据库连接池开启Flag
	 * @param isPoolS  Sql Server数据库连接池开启Flag
	 * @throws ServletException
	 */
	private void initConnectPool(boolean isPoolM, boolean isPoolO,
			boolean isPoolS) throws ServletException {

		Class<?> c = null;
		Constructor<?> constructor = null;
		try {
			log.info("开始初始化连接池。");
			c = Class.forName("com.utility.c3p0.ConnectUtil");		
			// 以下调用带参的、私有构造函数
			constructor = c
					.getDeclaredConstructor(new Class[] { DATABASETYPE.class });
			constructor.setAccessible(true);

			if (isPoolM) {

				this.cpdsMysql = (ConnectPool) (constructor
						.newInstance(new Object[] { DATABASETYPE.MYSQL }));

			}

			if (isPoolO) {

				this.cpdsOracle = (ConnectPool) (constructor
						.newInstance(new Object[] { DATABASETYPE.ORACLE }));

			}

			if (isPoolS) {

				this.cpdsMssql = (ConnectPool) (constructor
						.newInstance(new Object[] { DATABASETYPE.SQLSERVER }));

			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new ServletException(e);
		}
	}

	/**
	 * <b>重新载入配置文件</b> <br>
	 * 
	 */
	public void reloadConfig() {
		P.clear();
		P = null;
		initConfig(BASE_PATH + CONSTANT_PATH);
	}

	/**
	 * <b>初始化log4j</b> <br>
	 * 
	 * @param configPath
	 *            配置文件路径
	 * @param logDirectory
	 *            日志文件输出路径
	 */
	private void log4jInit(String configPath, String logDirectory) {
		File file = new File(configPath);
		if (!file.exists())
			return;
		try {
			InputStream in = new FileInputStream(file);
			Properties p = new Properties();
			p.load(in);

			// String basePath = logDirectory+File.separator;
			String basePath = logDirectory;

			if (p.getProperty("log4j.appender.infofile.File") != null) {
				p.setProperty(
						"log4j.appender.infofile.File",
						basePath
								+ p.getProperty("log4j.appender.infofile.File"));
			}

			if (p.getProperty("log4j.appender.errorlogfile.File") != null) {
				p.setProperty(
						"log4j.appender.errorlogfile.File",
						basePath
								+ p.getProperty("log4j.appender.errorlogfile.File"));
			}

			PropertyConfigurator.configure(p);
			in.close();
			 log.info("日志文件位置为："+logDirectory);
			
		} catch (Exception e) {
			System.out.println("加载log4j配置文件失败！");
		}

	}

	/**
	 * <b>得到Mysql连接池对象</b> <br>
	 * 
	 * @return 连接池
	 */
	public ConnectPool getCpdsMysql() {
		return cpdsMysql;
	}

	/**
	 * <b>得到Oracle连接池对象</b> <br>
	 * 
	 * @return 连接池
	 */
	public ConnectPool getCpdsOracle() {
		return cpdsOracle;
	}

	/**
	 * <b>得到Sql Server连接池对象</b> <br>
	 * 
	 * @return 连接池
	 */
	public ConnectPool getCpdsMssql() {
		return cpdsMssql;
	}

	/**
	 * <b>根据key从配置文件获取值</b> <br>
	 * 
	 * @param key
	 *            属性文件key
	 * @return 值
	 */
	public String getText(String key) {
		return P.getProperty(key);
	}

	/**
	 * <b>设置属性文件值</b> <br>
	 * 
	 * @param key
	 *            属性文件key
	 * @param value
	 *            值
	 */
	public void setText(String key, String value) {
		P.setProperty(key, value);
	}

	/**
	 * <b>得到属性对象</b> <br>
	 * 
	 * @return Properties对象
	 */
	public Properties getP() {
		return P;
	}

	/**
	 * <b>保存系统配置文件</b> <br>
	 * 
	 * @throws Exception
	 */
	public void saveConfig() throws Exception {
		OutputStream fos = new FileOutputStream(WebInitUtil.BASE_PATH
				+ WebInitUtil.CONSTANT_PATH);
		P.store(fos, "");
		fos.close();
	}

	/**
	 * <b>初始化配置文件</b> <br>
	 * 
	 * @param resourcePath
	 *            配置文件路径
	 */
	private void initConfig(String resourcePath) {
		File file = new File(resourcePath);
		if (!file.exists()) {
			return;
		} else {
			try {
				InputStream in = new FileInputStream(file);
				P = new Properties();
				P.load(in);
				in.close();
				log.info("加载配置文件成功！");
			} catch (Exception e) {				
				log.info("加载配置文件失败！");
				log.error(e);
			}
		}
	}

}
