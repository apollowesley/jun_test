package com.utility.c3p0;

import java.sql.Connection;
import java.sql.SQLException;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.utility.db.DBUtil.DATABASETYPE;
import com.utility.db.base.ConnectPool;
import com.utility.exception.SystemException;
import com.utility.log.LoggerUtil;

/**
 * <b>数据库连接实体</b> <br>
 *  支持c3p0链接池的plugin。发布为单独的c3p0-plugin-1.0.0.jar
 *  
 * @author XiaohuaFeng
 * @version 1.0 
 * @since 2015/04/08
 */
public class ConnectUtil implements ConnectPool {
	private static LoggerUtil log = new LoggerUtil(ConnectUtil.class);
	private ComboPooledDataSource cpds = null;
	/**
	 * <b>私有构造函数</b> <br>
	 * @param TYPE 数据库类型
	 */
	private ConnectUtil(DATABASETYPE TYPE) {
		try {
			switch (TYPE) {
			case MYSQL:
				this.cpds = new ComboPooledDataSource("mysql");
				log.info("mysql:连接池");
				break;
			case SQLSERVER:
				this.cpds = new ComboPooledDataSource("sqlserver");
				log.info("Sqlserver:连接池");
				break;
			case ORACLE:
				this.cpds = new ComboPooledDataSource("oracle");
				log.info("Oracle:连接池");
				break;
			}

			Connection conn = this.cpds.getConnection();
			conn.close();
			log.info("链接池初始化成功。");
		} catch (SQLException e) {
			log.info("链接池初始化失败。");
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志

		}
	}

	@Override
	public Connection getConnection() throws SystemException {
		// TODO Auto-generated method stub

		try {
			return this.cpds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);// 打印日志
			throw new SystemException(e);
		}

	}

	
	@Override
	public Connection getConnection(DATABASETYPE TYPE) {
		// TODO Auto-generated method stub
		return null;
	}

}
