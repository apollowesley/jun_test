package conn;

import java.sql.*;
/**
 * 
 * @author cy
 * @version 1.0
 * 
 */
public class DBConn {
	private final String DRIVER="com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private final String URL="jdbc:sqlserver://localhost:1434;databasename=Msg";
	private final String USERNAME="sa";
	private final String PWD="sa";
	
	private Connection conn=null;
	/**
	 * 
	 * @return Connection�����
	 */
	public Connection getConn(){
		try{
		Class.forName(DRIVER);
	    conn=DriverManager.getConnection(URL,USERNAME,PWD);
		}catch(ClassNotFoundException e){
			System.out.println("��������ʧ�ܣ�"+e.toString());
		}catch(SQLException e){
			System.out.println("���ݿ������ʧ�ܣ�"+e.toString());
		}finally{
	    
		}
		return conn;
	}
	
	/**
	 * 
	 * @param conn ����Connection�����
	 */
	public void close(Connection conn){

		try {
			if(conn!=null){
        	conn.close();
			} 
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace(); 
			}
    }
	public void close(ResultSet rs,Statement stat,Connection conn){
		try{
		if(rs!=null){
	    	rs.close();
	    } 
	    if(stat!=null){
	    	stat.close();
	    } 
	    if(conn!=null){
        	conn.close();
		} 
	    }catch(SQLException e){
			System.out.println("���ӹر�ʧ�ܣ�"+e.toString());
		}
	}
	    public void close(ResultSet rs,PreparedStatement pstat,Connection conn){
			try{
			if(rs!=null){
		    	rs.close();
		    } 
		    if(pstat!=null){
		    	pstat.close();
		    } 
		    if(conn!=null){
	        	conn.close();
			} 
		    }catch(SQLException e){
				System.out.println("���ӹر�ʧ�ܣ�"+e.toString());
			}
	}

    
}
