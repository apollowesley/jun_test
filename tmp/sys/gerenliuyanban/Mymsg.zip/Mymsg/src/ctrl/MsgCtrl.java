package ctrl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conn.DBConn;

import bean.Message;
import bean.MsgUser;

public class MsgCtrl {
	/**
	 * 
	 * @return �������е����Լ�¼
	 * 
	 */
	public List<Message> researchAll(){
		
		List<Message>  msglist=new ArrayList<Message>();
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		ResultSet  rs=null;
		String sql="select * from message   order by msg_id DESC";
		
		try {
			pstat=conn.prepareStatement(sql);
			rs=pstat.executeQuery();
			
			while(rs.next()){
				Message  msg=new Message();
				msg.setMsg_id(rs.getInt("msg_id"));
				msg.setMsg_subject(rs.getString("msg_subject"));
				msg.setMsg_content(rs.getString("msg_content"));
				msg.setMsg_reply(rs.getString("msg_reply"));
				msg.setUsername(rs.getString("username"));
				msg.setMsg_time(rs.getString("msg_time"));
			 
				msglist.add(msg);
			System.out.println(msg.getMsg_content());
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(rs, pstat, conn);
		}
		
		return msglist;
	}
	 /**
	  * 
	  * @param name ��������������
	  * @return ����ĳ������������Ϣ
	  * 
	  */
	public List<Message> researchAllByUser(String name){
		
		List<Message>  msglist=new ArrayList<Message>();
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		ResultSet  rs=null;
		String sql="select * from message where username=? order by msg_id DESC ";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, name);
			rs=pstat.executeQuery();
			
			while(rs.next()){
				Message  msg=new Message();
				msg.setMsg_id(rs.getInt("msg_id"));
				msg.setMsg_subject(rs.getString("msg_subject"));
				msg.setMsg_content(rs.getString("msg_content"));
				msg.setMsg_reply(rs.getString("msg_reply"));
				msg.setUsername(rs.getString("username"));
				msg.setMsg_time(rs.getString("msg_time"));
			   
				msglist.add(msg);
			System.out.println(msg.getMsg_content());
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(rs, pstat, conn);
		}
		
		return msglist;
	}
	/**
	 * 
	 * @param msg_id ��������id
	 * @return ����msg_id������Ӧ��һ���û�����
	 */
	public Message researchMsgById(int  msg_id){
		
		Message  msg=null;
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		ResultSet  rs=null;
		String sql="select * from message where msg_id=?";
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setInt(1, msg_id);
			rs=pstat.executeQuery();
			if(rs.next()){
				msg=new Message();
				msg.setMsg_id(rs.getInt("msg_id"));
				msg.setMsg_subject(rs.getString("msg_subject"));
				msg.setMsg_content(rs.getString("msg_content"));
				msg.setMsg_reply(rs.getString("msg_reply"));
				msg.setUsername(rs.getString("username"));
				msg.setMsg_time(rs.getString("msg_time"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(rs, pstat, conn);
		}
		
		return msg;
	}
	/**
	 * 
	 * @param msg ����Message��Ķ���
	 * @return ���ز������ݿ�Ľ��״̬
	 */
	public int addMsg(Message msg){
		int flag=0;
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="insert into message values(?,?,?,?,?)";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, msg.getMsg_subject());
			pstat.setString(2, msg.getMsg_content());
			pstat.setString(3, msg.getMsg_reply());
			pstat.setString(4, msg.getUsername());
			pstat.setString(5, msg.getMsg_time());
			
			flag=pstat.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			db.close(null, pstat, conn);
		}
		return flag;
	}
	
	
	public int updateMsg(Message msg){
		int flag=0;
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="update message set msg_subject=?,msg_content=? where msg_id=?";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, msg.getMsg_subject());
			pstat.setString(2, msg.getMsg_content());
			pstat.setInt(3, msg.getMsg_id());
			flag=pstat.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			db.close(null, pstat, conn);
		}
		return flag;
	}
	
	public int delMsg(int id){
		int flag=0;
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="delete  message  where msg_id=?";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setInt(1, id);
			flag=pstat.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			db.close(null, pstat, conn);
		}
		return flag;
	}
	
	public int replyMsg(Message msg){
		int flag=0;
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="update message set msg_reply=? where msg_id=?";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, msg.getMsg_reply());
			pstat.setInt(2, msg.getMsg_id());
			flag=pstat.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			db.close(null, pstat, conn);
		}
		return flag;
	}
}
