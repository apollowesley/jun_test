package ctrl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conn.DBConn;

import bean.Message;
import bean.MsgUser;

public class UserCtrl {
	/**
	 * 
	 * @param user
	 * @return ����û���¼��Ϣ
	 */
	
	public int checkUser(MsgUser user){
		int flag=0;
		
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		ResultSet  rs=null;
		String sql="select * from t_user where username=? and pwd=?";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, user.getUsername());
			pstat.setString(2, user.getPwd());
			
			rs=pstat.executeQuery();
			if(rs.next()){
				flag=Integer.parseInt(rs.getString("power"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(rs, pstat, conn);
		}
		
		return flag;
	}
	/**
	 * �����û�������һ���û���������Ϣ
	 * @param username
	 * @return
	 */
	public MsgUser researchByusername(String username){
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		ResultSet  rs=null;
		String sql="select * from t_user where username=? ";
		MsgUser   msguser=null;
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, username.trim());
			
			rs=pstat.executeQuery();
			
			if(rs.next()){
			
				msguser=new MsgUser();
				msguser.setUser_id(rs.getInt("user_id")); 
				msguser.setUsername(rs.getString("username").trim());
				msguser.setPwd(rs.getString("pwd").trim());
				msguser.setSex(rs.getString("sex").trim());
				msguser.setPower(rs.getString("power").trim());
				msguser.setHeadimage(rs.getString("headimage").trim());
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(rs, pstat, conn);
		}
		
		return msguser;
	}
	
	public MsgUser researchByID(int  id){
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		ResultSet  rs=null;
		String sql="select * from t_user where user_id=? ";
		MsgUser   msguser=null;
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setInt(1, id);
			
			rs=pstat.executeQuery();
			if(rs.next()){
				msguser=new MsgUser();
				msguser.setUser_id(rs.getInt("user_id")); 
				msguser.setUsername(rs.getString("username").trim());
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(rs, pstat, conn);
		}
		
		return msguser;
	}
	/**
	 * 
	 * @param user
	 * @return ����һ���û���Ϣ
	 */
	public int addUser(MsgUser user){
		int flag=0; 
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="insert into t_user values(?,?,?,?,?)";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, user.getUsername());
			pstat.setString(2, user.getPwd());
			pstat.setString(3, user.getPower());
			pstat.setString(4, user.getSex());
			pstat.setString(5, user.getHeadimage());
			flag=pstat.executeUpdate();
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(null, pstat, conn);
		}
		
		return flag;
	}
	/**
	 * �����û�id�޸��û���Ϣ
	 * @param user
	 * @return
	 */
	public int updateUser(MsgUser user){
		int flag=0; 
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="update t_user set pwd=?,sex=?,headimage=? where user_id=?";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, user.getPwd());			
			pstat.setString(2, user.getSex());
			pstat.setString(3, user.getHeadimage());
			pstat.setInt(4, user.getUser_id());
			flag=pstat.executeUpdate();
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(null, pstat, conn);
		}
		
		return flag;
	}
	
	public int adminupdateUser(MsgUser user){
		int flag=0; 
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="update t_user set pwd=? where user_id=?";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, user.getPwd());			
			pstat.setInt(2, user.getUser_id());
			flag=pstat.executeUpdate();
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			db.close(null, pstat, conn);
		}
		
		return flag;
	}
	
	
	public List<MsgUser> researchAllUser(){ 
	       List<MsgUser>  userlist=new ArrayList<MsgUser>();//����list���ͼ��ϣ���ʵ����
	       DBConn   db=new DBConn();//������Ӧ�������
	       Connection  conn=db.getConn();//���ز�ע���������������Ӷ��󷵻�
	       PreparedStatement pstat=null;
			ResultSet  rs=null;
	 	   String sql="select * from t_user order by user_id ASC";//�����ѯ�����û���sql���
	 	    try {
				pstat=conn.prepareStatement(sql);//����Ԥ����ִ�ж���
				rs=pstat.executeQuery();//ִ��sql��䣬������������ڽ����¼����
				while(rs.next()){//�α����һ����¼�������¼����
					MsgUser  user=new MsgUser();
					user.setUser_id(rs.getInt("user_id"));
					user.setUsername(rs.getString("username"));
					user.setPwd(rs.getString("pwd"));
					user.setHeadimage(rs.getString("headimage"));
					userlist.add(user);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("��ѯ�����û�ʧ�ܣ�"+e.toString());
			}finally{
				
				db.close(rs, pstat, conn);
				
			}
			
			return userlist;
	    }
	public int delete(int id){
		int flag=0;
		DBConn   db=new DBConn();
		Connection conn=db.getConn();
		PreparedStatement pstat=null;
		String sql="delete  t_user  where user_id=?";
		
		try {
			pstat=conn.prepareStatement(sql);
			pstat.setInt(1, id);
			flag=pstat.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			db.close(null, pstat, conn);
		}
		return flag;
	}
	
	
}
