package bean;
/**
 * 
 * @author cy
 *
 */
public class Message {
	
	private int msg_id;
	private String msg_subject;
	private String msg_content;
	private String msg_reply;
	private String username;
	private String msg_time;
	public int getMsg_id() {
		return msg_id;
	}
	public void setMsg_id(int msgId) {
		msg_id = msgId;
	}
	public String getMsg_subject() {
		return msg_subject;
	}
	public void setMsg_subject(String msgSubject) {
		msg_subject = msgSubject;
	}
	public String getMsg_content() {
		return msg_content;
	}
	public void setMsg_content(String msgContent) {
		msg_content = msgContent;
	}
	public String getMsg_reply() {
		return msg_reply;
	}
	public void setMsg_reply(String msgReply) {
		msg_reply = msgReply;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMsg_time() {
		return msg_time;
	}
	public void setMsg_time(String msgTime) {
		msg_time = msgTime;
	}
	
	

}
