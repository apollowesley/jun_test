package myutil;

import java.util.Date;

public class Mydate {

	    Date d=null;
	
	public  String getDate(){
		String strdate="";
		d=new Date();
				
		strdate=(d.getYear()+1900)+"��"+(d.getMonth()+1)+"��"+d.getDate()+"��"+(d.getHours()+1)+"ʱ"+d.getMinutes()+"��"+d.getSeconds()+"��";
		
		return strdate;
	}
	/*public static void main(String args[]){
		Mydate  m=new Mydate();
		System.out.println(m.getDate());
	}*/
	
}
