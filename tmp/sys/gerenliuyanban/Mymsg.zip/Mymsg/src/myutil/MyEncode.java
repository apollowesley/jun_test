package myutil;

import java.io.UnsupportedEncodingException;

public class MyEncode {

	public static String encode(String str){
		String tempstr="";
		
		try {
			tempstr=new String(str.getBytes("ISO-8859-1"),"GBK");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tempstr;
	}
	
}
