<template>
	<view>
		<page-head :title="title"></page-head>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				title: '当前页'
			}
		}
	}
</script>
