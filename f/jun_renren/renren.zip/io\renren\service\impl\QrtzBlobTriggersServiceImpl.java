package io.renren.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import io.renren.dao.QrtzBlobTriggersDao;
import io.renren.entity.QrtzBlobTriggersEntity;
import io.renren.service.QrtzBlobTriggersService;



@Service("qrtzBlobTriggersService")
public class QrtzBlobTriggersServiceImpl implements QrtzBlobTriggersService {
	@Autowired
	private QrtzBlobTriggersDao qrtzBlobTriggersDao;
	
	@Override
	public QrtzBlobTriggersEntity queryObject(String schedName){
		return qrtzBlobTriggersDao.queryObject(schedName);
	}
	
	@Override
	public List<QrtzBlobTriggersEntity> queryList(Map<String, Object> map){
		return qrtzBlobTriggersDao.queryList(map);
	}
	
	@Override
	public int queryTotal(Map<String, Object> map){
		return qrtzBlobTriggersDao.queryTotal(map);
	}
	
	@Override
	public void save(QrtzBlobTriggersEntity qrtzBlobTriggers){
		qrtzBlobTriggersDao.save(qrtzBlobTriggers);
	}
	
	@Override
	public void update(QrtzBlobTriggersEntity qrtzBlobTriggers){
		qrtzBlobTriggersDao.update(qrtzBlobTriggers);
	}
	
	@Override
	public void delete(String schedName){
		qrtzBlobTriggersDao.delete(schedName);
	}
	
	@Override
	public void deleteBatch(String[] schedNames){
		qrtzBlobTriggersDao.deleteBatch(schedNames);
	}
	
}
