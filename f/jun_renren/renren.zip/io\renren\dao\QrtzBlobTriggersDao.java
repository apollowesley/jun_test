package io.renren.dao;

import io.renren.entity.QrtzBlobTriggersEntity;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2016-12-25 22:29:52
 */
public interface QrtzBlobTriggersDao extends BaseDao<QrtzBlobTriggersEntity> {
	
}
