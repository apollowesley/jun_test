package io.renren.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.renren.entity.QrtzBlobTriggersEntity;
import io.renren.service.QrtzBlobTriggersService;
import io.renren.utils.PageUtils;
import io.renren.utils.R;


/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2016-12-25 22:29:52
 */
@RestController
@RequestMapping("qrtzblobtriggers")
public class QrtzBlobTriggersController {
	@Autowired
	private QrtzBlobTriggersService qrtzBlobTriggersService;
	
	/**
	 * 列表
	 */
	@RequestMapping("/list")
	//@RequiresPermissions("qrtzblobtriggers:list")
	public R list(Integer page, Integer limit){
		Map<String, Object> map = new HashMap<>();
		map.put("offset", (page - 1) * limit);
		map.put("limit", limit);
		
		//查询列表数据
		List<QrtzBlobTriggersEntity> qrtzBlobTriggersList = qrtzBlobTriggersService.queryList(map);
		int total = qrtzBlobTriggersService.queryTotal(map);
		
		PageUtils pageUtil = new PageUtils(qrtzBlobTriggersList, total, limit, page);
		
		return R.ok().put("page", pageUtil);
	}
	
	
	/**
	 * 信息
	 */
	@RequestMapping("/info/{schedName}")
	//@RequiresPermissions("qrtzblobtriggers:info")
	public R info(@PathVariable("schedName") String schedName){
		QrtzBlobTriggersEntity qrtzBlobTriggers = qrtzBlobTriggersService.queryObject(schedName);
		
		return R.ok().put("qrtzBlobTriggers", qrtzBlobTriggers);
	}
	
	/**
	 * 保存
	 */
	@RequestMapping("/save")
	//@RequiresPermissions("qrtzblobtriggers:save")
	public R save(@RequestBody QrtzBlobTriggersEntity qrtzBlobTriggers){
		qrtzBlobTriggersService.save(qrtzBlobTriggers);
		
		return R.ok();
	}
	
	/**
	 * 修改
	 */
	@RequestMapping("/update")
	//@RequiresPermissions("qrtzblobtriggers:update")
	public R update(@RequestBody QrtzBlobTriggersEntity qrtzBlobTriggers){
		qrtzBlobTriggersService.update(qrtzBlobTriggers);
		
		return R.ok();
	}
	
	/**
	 * 删除
	 */
	@RequestMapping("/delete")
	//@RequiresPermissions("qrtzblobtriggers:delete")
	public R delete(@RequestBody String[] schedNames){
		qrtzBlobTriggersService.deleteBatch(schedNames);
		
		return R.ok();
	}
	
}
