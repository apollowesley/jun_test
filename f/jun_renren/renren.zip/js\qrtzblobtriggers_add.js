var schedName = T.p("schedName");
var vm = new Vue({
	el:'#rrapp',
	data:{
		title:"新增",
		qrtzBlobTriggers:{}
	},
	created: function() {
		if(schedName != null){
			this.title = "修改";
			this.getInfo(schedName)
		}
    },
	methods: {
		getInfo: function(schedName){
			$.get("../qrtzblobtriggers/info/"+schedName, function(r){
                vm.qrtzBlobTriggers = r.qrtzBlobTriggers;
            });
		},
		saveOrUpdate: function (event) {
			var url = vm.qrtzBlobTriggers.schedName == null ? "../qrtzblobtriggers/save" : "../qrtzblobtriggers/update";
			$.ajax({
				type: "POST",
			    url: url,
			    data: JSON.stringify(vm.qrtzBlobTriggers),
			    success: function(r){
			    	if(r.code === 0){
						alert('操作成功', function(index){
							vm.back();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		back: function (event) {
			history.go(-1);
		}
	}
});