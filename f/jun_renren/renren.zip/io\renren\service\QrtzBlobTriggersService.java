package io.renren.service;

import io.renren.entity.QrtzBlobTriggersEntity;

import java.util.List;
import java.util.Map;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2016-12-25 22:29:52
 */
public interface QrtzBlobTriggersService {
	
	QrtzBlobTriggersEntity queryObject(String schedName);
	
	List<QrtzBlobTriggersEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(QrtzBlobTriggersEntity qrtzBlobTriggers);
	
	void update(QrtzBlobTriggersEntity qrtzBlobTriggers);
	
	void delete(String schedName);
	
	void deleteBatch(String[] schedNames);
}
